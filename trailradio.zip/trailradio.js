/* Code to Toggle the sign up and sign in modes starts here*/

const sign_in_btn = document.querySelector("#sign-in-btn");
var sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
    });

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});

/* Code to Toggle the sign up and sign in modes ends here*/


/*functions on radio buttons starts here*/








/*functions on radio buttons ends here*/